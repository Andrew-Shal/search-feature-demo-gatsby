import React from 'react'

const HomePageSearch = () => {
    return <h2>This is a homepage search bar component</h2>
}

export default HomePageSearch
