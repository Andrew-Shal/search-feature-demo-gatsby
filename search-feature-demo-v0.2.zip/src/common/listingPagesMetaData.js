export const listingPagesMetaData = [
    { id: 1, slug: '/real-estate/listings', label: 'Real Estates', value: 'real-estate' },
    { id: 2, slug: '/hotel/listings', label: 'Hotels', value: 'hotel' },
    { id: 3, slug: '/land/listings', label: 'Lands', value: 'land' },
]
